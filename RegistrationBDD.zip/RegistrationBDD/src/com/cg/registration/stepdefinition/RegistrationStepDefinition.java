package com.cg.registration.stepdefinition;

import java.sql.Driver;

import org.junit.Assert;
import org.openqa.selenium.WebDriver;
import org.openqa.selenium.chrome.ChromeDriver;
import org.openqa.selenium.support.PageFactory;

import com.cg.registration.pagebeans.RegistrationPageBean;

import cucumber.api.java.en.Given;
import cucumber.api.java.en.Then;
import cucumber.api.java.en.When;

public class RegistrationStepDefinition {

	private WebDriver driver=new ChromeDriver();
	private RegistrationPageBean pageBean;
	
	@Given("^User is accessing RegistrationPage on Browser\\.$")
	public void user_is_accessing_RegistrationPage_on_Browser() throws Throwable {
	    driver.get("D:\\Users\\ADM-IG-HWDLAB1D\\Downloads\\WebPages\\RegistrationForm.html");
	    pageBean=PageFactory.initElements(driver, RegistrationPageBean.class);
	}

	@When("^User is trying submit data without entering 'User Id'\\.$")
	public void user_is_trying_submit_data_without_entering_User_Id() throws Throwable {
	    pageBean.clickSignUp();
	}

	@Then("^'User Id' should not be empty/length be between (\\d+) to (\\d+) alert message should display\\.$")
	public void user_Id_should_not_be_empty_length_be_between_to_alert_message_should_display(int arg1, int arg2) throws Throwable{
	  String expectedAlertMessage="User Id should not be empty / length be between 5 to 12";
	  String actualAlertmessage=driver.switchTo().alert().getText();
	  Assert.assertEquals(expectedAlertMessage, actualAlertmessage);
	}

	@When("^User is trying to submit request without entering 'username'$")
	public void user_is_trying_to_submit_request_without_entering_username() throws Throwable {
	   driver.switchTo().alert().dismiss();
	}

	@Then("^'Username should not be empty and must have alphabet characters only' alert message should display\\.$")
	public void name_should_not_be_empty_and_must_have_alphabet_characters_only_alert_message_should_display() throws Throwable {
	   String expectedAlertMessage="Username should not be empty and must have alphabet characters only";
	   String actualAlertmessage=driver.switchTo().alert().getText();
		  Assert.assertEquals(expectedAlertMessage, actualAlertmessage);
	}
	@When("^User is trying to submit request without entering 'password'$")
	public void user_is_trying_to_submit_request_without_entering_password() throws Throwable {
		 driver.switchTo().alert().dismiss();
		 pageBean.setUsername("hayafa");
		 pageBean.clickSignUp();
	}

	@Then("^'Password should not be empty/length be between (\\d+) to (\\d+)' alert message should display\\.$")
	public void password_should_not_be_empty_length_be_between_to_alert_message_should_display(int arg1, int arg2) throws Throwable {
	   String expectedAlertMessage="Password should not be empty / length be between 7 to 12";
	   String actualAlertmessage=driver.switchTo().alert().getText();
		  Assert.assertEquals(expectedAlertMessage, actualAlertmessage);
	}
	@When("^User is trying to submit request without entering 'Address'$")
	public void user_is_trying_to_submit_request_without_entering_Address() throws Throwable {
		driver.switchTo().alert().dismiss();
		 pageBean.setAddress("Pune421002");
		 pageBean.clickSignUp();
	}

	@Then("^'User address must have alphanumeric characters only' alert message should display\\.$")
	public void address_should_not_be_empty_alert_message_should_display() throws Throwable {
		String expectedAlertMessage="User address must have alphanumeric characters only";
		   String actualAlertmessage=driver.switchTo().alert().getText();
			  Assert.assertEquals(expectedAlertMessage, actualAlertmessage);
	}

	@When("^User is trying to submit request without selecting valid 'Country'$")
	public void user_is_trying_to_submit_request_without_selecting_valid_Country() throws Throwable {
		driver.switchTo().alert().dismiss();
		 pageBean.setCountry("India");
		 pageBean.clickSignUp();
	}

	@Then("^'Select your country from the list' alert message should display\\.$")
	public void please_select_any_one_country_from_the_provided_list_alert_message_should_display() throws Throwable {
		  String expectedAlertMessage="Select your country from the list";
		   String actualAlertmessage=driver.switchTo().alert().getText();
			  Assert.assertEquals(expectedAlertMessage, actualAlertmessage);
	}

	@When("^User is trying to submit request without selecting valid 'Zip Code'$")
	public void user_is_trying_to_submit_request_without_selecting_valid_Zip_Code() throws Throwable {
		driver.switchTo().alert().dismiss();
		 pageBean.setCountry("423011");
		 pageBean.clickSignUp();
	}

	@Then("^'ZIP code must have numeric characters only' alert message should display\\.$")
	public void zip_Code_must_have_numeric_characters_only_alert_message_should_display() throws Throwable {
		 String expectedAlertMessage="ZIP code must have numeric characters only";
		   String actualAlertmessage=driver.switchTo().alert().getText();
			  Assert.assertEquals(expectedAlertMessage, actualAlertmessage);
	}

	@When("^User is trying to submit request without selecting valid 'Email'$")
	public void user_is_trying_to_submit_request_without_selecting_valid_Email() throws Throwable {
		driver.switchTo().alert().dismiss();
		pageBean.setZip("423011");
		 pageBean.setEmail("hayafa786@gmail.com");
		 pageBean.clickSignUp();
	}

	@Then("^'You have entered an invalid email address!' alert message should display\\.$")
	public void you_have_entered_an_invalid_email_address_alert_message_should_display() throws Throwable {
		 String expectedAlertMessage="You have entered an invalid email address!";
		   String actualAlertmessage=driver.switchTo().alert().getText();
			  Assert.assertEquals(expectedAlertMessage, actualAlertmessage);
	}

	@When("^User is trying to submit request without selecting valid 'Gender'$")
	public void user_is_trying_to_submit_request_without_selecting_valid_Gender() throws Throwable {
		driver.switchTo().alert().dismiss();
		 pageBean.setEmail("hayafa786@gmail.com");
		 pageBean.clickSignUp();
	}

	@Then("^'Please Select gender' alert message should display\\.$")
	public void please_select_gender_alert_message_should_display() throws Throwable {
		 String expectedAlertMessage="Please Select gender";
		   String actualAlertmessage=driver.switchTo().alert().getText();
			  Assert.assertEquals(expectedAlertMessage, actualAlertmessage);
	}


	@When("^User is trying to submit request after entering valid set of information\\.$")
	public void user_is_trying_to_submit_request_after_entering_valid_set_of_information() throws Throwable {
	    pageBean.setUserId("hayafa");
	    pageBean.setUsername("hayfa");
	    pageBean.setPassword("hayafahaya");
	    pageBean.setAddress("Pune421002");
	    pageBean.setCountry("India");
	    pageBean.setZip("423011");
	    pageBean.setEmail("hayafa786@gmail.com");
	    pageBean.setGender("Female");
	    pageBean.clickSignUp();
	}

	@Then("^'Your Registration with JobsWorld\\.com has successfully done plz check your registred email addres to activate your profile'$")
	public void your_Registration_with_JobsWorld_com_has_successfully_done_plz_check_your_registred_email_addres_to_activate_your_profile() throws Throwable {
		String expectedAlertMessage="Your Registration with JobsWorld.com has successfully done plz check your registred email addres to activate your profile";
		   String actualAlertmessage=driver.switchTo().alert().getText();
			  Assert.assertEquals(expectedAlertMessage, actualAlertmessage);
	}
}
